package padroescriacao.abstractfactory;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LojaTest {

    @Test
    void deveEmitirTroca() {
        FabricaAbstrata fabrica = new FabricaTroca();
        Loja loja = new Loja(fabrica);
        assertEquals("Registro Troca de Produto", loja.emitirRegistro());
    }

    @Test
    void deveEmitirCompraVenda() {
        FabricaAbstrata fabrica = new FabricaCompraVenda();
        Loja loja = new Loja(fabrica);
        assertEquals("Registro Compra e Venda de produto", loja.emitirRegistro());
    }

}