package padroescriacao.abstractfactory;

public class FabricaTroca implements FabricaAbstrata {

    @Override
    public Registro createRegistro() {
        return new Troca();
    }
}
