package padroescriacao.abstractfactory;

public class Troca implements Registro {

    public String emitir() {
        return "Registro Troca de Produto";
    }
}
