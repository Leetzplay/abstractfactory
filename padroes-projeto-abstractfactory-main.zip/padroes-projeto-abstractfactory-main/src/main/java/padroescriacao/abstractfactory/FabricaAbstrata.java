package padroescriacao.abstractfactory;

public interface FabricaAbstrata {
    Registro createRegistro();
    Produtos createProdutos();
}
