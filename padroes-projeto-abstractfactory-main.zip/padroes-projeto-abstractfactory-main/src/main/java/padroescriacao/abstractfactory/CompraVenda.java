package padroescriacao.abstractfactory;

public class CompraVenda implements Registro {

    public String emitir() {
        return "Registro Compra e Venda de Produtos";
    }
}
