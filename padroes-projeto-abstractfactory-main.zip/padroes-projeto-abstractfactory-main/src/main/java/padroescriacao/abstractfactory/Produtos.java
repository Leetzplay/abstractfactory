package padroescriacao.abstractfactory;

public interface Produtos {

    String emitir();
}
