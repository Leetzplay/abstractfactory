package padroescriacao.abstractfactory;

public class Loja {

    private Registro registro;
    private Produtos produtos;

    public Loja(FabricaAbstrata fabrica) {
        this.registro = fabrica.createRegistro();
        this.produtos = fabrica.createProdutos();
    }

    public String emitirRegistro() {
        return this.registro.emitir();
    }

    public String emitirProdutos() {
        return this.produtos.emitir();
    }
}
